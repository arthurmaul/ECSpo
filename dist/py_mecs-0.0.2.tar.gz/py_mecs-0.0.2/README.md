# Mecs2
## A simple ecs implementation in 50 lines.
